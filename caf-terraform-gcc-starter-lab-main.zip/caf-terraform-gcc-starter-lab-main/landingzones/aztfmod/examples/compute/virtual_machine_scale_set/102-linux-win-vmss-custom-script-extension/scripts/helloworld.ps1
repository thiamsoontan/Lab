Start-Transcript -Path c:\helloworld.txt
write-output "Hello, World!"
stop-transcript
