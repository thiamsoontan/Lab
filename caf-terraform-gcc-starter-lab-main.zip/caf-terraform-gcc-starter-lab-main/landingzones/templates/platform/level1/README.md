# Cloud Adoption Framework landing zones for Terraform - Starter template

Place here your production environment configuration files.