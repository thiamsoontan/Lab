
## Template to generate the defitions for the Orion data and ai landingzones

```bash
/tf/caf/landingzones/templates/asvm/orion/deploy_template.sh

```