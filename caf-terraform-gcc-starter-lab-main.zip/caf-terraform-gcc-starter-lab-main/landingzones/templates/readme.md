# Rover ignite

Rover Ignite allows you to create a coherent stack of configuration files for CAF Terraform landing zones.
It integrates all levels in a consistent and interactive way.
In some configuration, the output of an execution is needed to continue, you might have to run multiple times the rover ignite command in order to generate the full configuration files.

You have now created the configuration files and are ready to proceed with the deployment.

[Go to](./level0/readme.md)