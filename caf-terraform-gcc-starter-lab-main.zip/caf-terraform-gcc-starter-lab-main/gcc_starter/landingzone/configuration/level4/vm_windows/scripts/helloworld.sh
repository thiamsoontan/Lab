#!/usr/bin/env bash

echo "Hello, World!" > hello.log
