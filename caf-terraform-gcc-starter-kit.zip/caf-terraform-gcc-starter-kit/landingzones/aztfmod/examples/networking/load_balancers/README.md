# Azure Load Balancers

The examples in this folders are kept for backward compatibility and are considered as deprecated.

We recommend you review the examples inside the ../lb folder.