Start-Transcript -Path c:\helloworld.txt
write-output "hello world"
stop-transcript