=======================================================
# Create container group with system-managed identity
========================================================
az container create \
  --resource-group myResourceGroup \
  --name mycontainer \
  --image mcr.microsoft.com/azure-cli \
  --assign-identity --scope $RG_ID \
  --command-line "tail -f /dev/null"

az group create --name rg-launchpad --location southeastasia
RG_ID=$(az group show --name rg-launchpad --query id --output tsv)

az container create \
  --name aci-rovercontainer \
  --resource-group rg-launchpad \
  --image aztfmod/rover:1.5.2-2307.0508 \
  --vnet vnet-aci \
  --vnet-address-prefix 172.16.0.0/20 \
  --subnet snet-aci  \
  --subnet-address-prefix 172.16.0.0/24
  --assign-identity --scope $RG_ID \
  --command-line "/bin/sh", "-c", "while sleep 1000; do :; done"


az container show \
  --resource-group rg-launchpad \
  --name aci-rovercontainer


SP_ID=$(az container show \
  --resource-group rg-launchpad \
  --name aci-rovercontainer \
  --query identity.principalId --out tsv)

az container exec \
  --resource-group rg-launchpad \
  --name aci-rovercontainer \
  --exec-command "/bin/bash"

az login --identity
