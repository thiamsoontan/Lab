# deployment
# starter kit launchpad setup
# 1. create a bastion host

see steps in /tf/caf/gcc_starter/Starter_launchpad_README.md

# login to tenant - must use this to login
az login --tenant [tenant id] e.g. htx sandpit ac20add1-ffda-45c1-adc5-16a0db15810f

# subscription
az account set --subscription [your subscription id] 
# set to subscription
az account set --subscription 6f035180-4066-42f0-b0fa-5fbc1ae67500
replace moris to escep


Steps
1. create development environment
go to /tf/caf/gcc_starter/gcc-dev-env/README.md

# launchpad
=================================================================================

2. ok - launchpad - /tf/caf/gcc_starter/landingzone/configuration/level0/launchpad

rover -lz /tf/caf/landingzones/caf_launchpad \
  -launchpad \
  -var-folder /tf/caf/gcc_starter/landingzone/configuration/level0/launchpad \
  -env uat \
  -skip-permission-check \
  -a plan

# networking
=================================================================================

3. ok - level 3 - shared services - /tf/caf/gcc_starter/landingzone/configuration/level3/shared_services

rover -lz rover -lz /tf/caf/landingzones/caf_solution \
  -level level3 \
  -var-folder /tf/caf/gcc_starter/landingzone/configuration/level3/shared_services \
  -parallelism 30 \
  -env uat \
  -skip-permission-check \
  -tfstate shared_services.tfstate \
  -a plan

4. ok - level 3 - management - /tf/caf/gcc_starter/landingzone/configuration/level3/networking_spoke_management

rover -lz rover -lz /tf/caf/landingzones/caf_solution \
-level level3 \
-var-folder /tf/caf/gcc_starter/landingzone/configuration/level3/networking_spoke_management \
-parallelism 30 \
-env uat \
-tfstate networking_spoke_management.tfstate \
-a plan

5. ok level 3 - devops - /tf/caf/gcc_starter/landingzone/configuration/level3/networking_spoke_devops

rover -lz /tf/caf/landingzones/caf_solution \
-level level3 \
-var-folder /tf/caf/gcc_starter/landingzone/configuration/level3/networking_spoke_devops \
-parallelism 30 \
-env uat \
-tfstate networking_spoke_devops.tfstate \
-a plan

6. level 3 - hub internet - /tf/caf/gcc_starter/landingzone/configuration/level3/networking_hub_internet

rover -lz rover -lz /tf/caf/landingzones/caf_solution \
-level level3 \
-var-folder /tf/caf/gcc_starter/landingzone/configuration/level3/networking_hub_internet \
-env uat \
-tfstate networking_hub_internet.tfstate \
-a plan

7. level 3 - hub intranet - /tf/caf/gcc_starter/landingzone/configuration/level3/networking_hub_intranet

rover -lz rover -lz /tf/caf/landingzones/caf_solution \
-level level3 \
-var-folder /tf/caf/gcc_starter/landingzone/configuration/level3/networking_hub_intranet \
-env uat \
-tfstate networking_hub_intranet.tfstate \
-a plan

8. level 3 - spoke project - /tf/caf/gcc_starter/landingzone/configuration/level3/networking_spoke_internet

rover -lz rover -lz /tf/caf/landingzones/caf_solution \
-level level3 \
-var-folder /tf/caf/gcc_starter/landingzone/configuration/level3/networking_spoke_internet \
-env uat \
-tfstate networking_spoke_internet.tfstate \
-a plan


# firewall, application gateway
===============================

9. egress firewall internet

10. egress firewall intranet

11. agw internet

12. agw intranet

13. ingress firewall internet

14. ingress firewall intranet


# level 4 - solution accelerators
================================================================================


# DevOps, Management Zone
===============================

18. bastion host

19. tooling vm

20. runner vm or container instances

# Project
===============================

21. sql server

22. acr

23. aks

24. deploy sample azure-vote application and validation through internet and intranet



