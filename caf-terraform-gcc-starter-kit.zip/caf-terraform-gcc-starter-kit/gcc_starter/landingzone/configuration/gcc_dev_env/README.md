# Terraform for GCC development environment
##### Original Authored by: Jason Pang  

Use your MSDN Subscription

# Login to Azure
```bash
rover login
# sandpit
az login --tenant [tenant id] # e.g. htx sandpit ac20add1-ffda-45c1-adc5-16a0db15810f 
```

# optional - set to correct subscription
```bash
az account set --subscription <your subscription id>

# Create GCC Development Environment
```bash
cd /tf/caf/gcc_starter/landingzone/configuration/gcc_dev_env

terraform init

terraform plan

terraform apply

cd ..

```

# Next step
# Goto README.md at /tf/caf/gcc_starter/landingzone/configuration/level0/launchpad/README.md
